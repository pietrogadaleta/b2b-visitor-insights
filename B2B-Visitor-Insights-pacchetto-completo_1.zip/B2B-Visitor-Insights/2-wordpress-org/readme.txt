=== B2B Visitor Insights ===
Contributors: YOUR-WPORG-USERNAME
Tags: b2b, lead generation, visitor identification, reverse ip, analytics
Requires at least: 6.3
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Know which companies visit your site — no SaaS, your data stays in WordPress. Free, with a free IPinfo API token.

== Description ==

**B2B Visitor Insights is 100% free.** No subscription, no external dashboard, no SaaS account. All you need is a **free IPinfo API token** (ipinfo.io Lite plan), which takes two minutes to create.

Most B2B visitors never fill in a form. This plugin tells you which companies were on your site anyway: it looks up the visitor's IP address with IPinfo, finds the organization that owns the network, and shows you which pages each company read and how interested it looks. Everything is stored in your own WordPress database.

= Why B2B Visitor Insights =

Most visitor identification tools for WordPress are just a connector: they add a script to your site, send your visitors' data to the vendor's servers, and show the results in a paid external dashboard.

B2B Visitor Insights works the other way round:

* **No SaaS, no subscription:** the dashboard is inside your WordPress admin.
* **Your data stays in WordPress:** companies and visits are saved in your own database. Only the IP address is sent to IPinfo for the lookup, and nothing is sent to us.
* **Free:** works with the free IPinfo Lite plan. Upgrade only if you want more matches.
* **Respects your cookie banner:** nothing is tracked before consent.
* **Lightweight and SEO safe:** no impact on Core Web Vitals, no changes to your pages.

= How it works =

1. A visitor accepts statistics or marketing cookies on your cookie banner.
2. A tiny script sends the page view to your own website (WordPress REST API).
3. Your server asks IPinfo which organization owns the visitor's IP address.
4. Home, mobile and internet-provider connections are discarded. Company networks are kept.
5. The company appears in **B2B Visitors → Companies**, with every page it viewed, and you get an email alert.

= Setup in 5 steps =

1. **Install and activate** B2B Visitor Insights.
2. **Create your free IPinfo token**: sign up at https://ipinfo.io/signup, open the Dashboard and copy the token (only the token, not a URL).
3. Go to **B2B Visitors → Settings**, paste the token, keep the plan on **Lite (free)** and click **Test lookup** with 8.8.8.8. The result should be "Google LLC – ISP / hosting – discarded": this means the token works.
4. Add your own office IP address to **Excluded IPs** (your current IP is shown on the page) and list your high-intent pages in **Hot pages**, for example `contact,pricing,quote,services`.
5. Tick **Enable the tracking script**, save, and clear your page cache. Companies will appear as they visit your site.

Optional: if your site is behind the Cloudflare proxy (orange cloud) and the "current IP" shown in the settings is a Cloudflare address, enter `CF-Connecting-IP` in **Real IP header**.

= Features =

* Companies dashboard: sessions, page views, last visit and an interest score (High / Medium / Low).
* Hot pages: extra weight for pricing, contact or service pages.
* Company timeline: every session with pages, time on page, referrer and UTM parameters.
* Email alert when a new company is identified.
* Optional contact enrichment: public email, phone and LinkedIn page read from the company's own website.
* "Find people" shortcut to search the company's team on LinkedIn.
* CSV export, ready for Excel or your CRM.
* Developer hooks to connect other providers or your CRM.

= No impact on Core Web Vitals =

* One small script (about 1.6 KB gzipped), loaded with `defer` in the footer: it never blocks rendering.
* No CSS, fonts, images or jQuery on the front end, and nothing is added to the page layout, so LCP, INP and CLS are not affected.
* The IP lookup runs on your server in a separate request after the page has loaded, and each IP is looked up once at most every 30 days.
* Works with page caching and optimization plugins (WP Rocket, LiteSpeed Cache, W3 Total Cache and similar). With "delay JavaScript", tracking simply starts at the first user interaction.

= SEO and GEO friendly =

* No changes to your content, HTML markup, titles, meta tags, canonicals or structured data.
* No redirects, no cloaking: search engine crawlers and AI crawlers (Googlebot, Bingbot, GPTBot, ClaudeBot, PerplexityBot and others) see exactly the same page as visitors.
* Bots and crawlers are ignored by the tracker, so they do not pollute your data or trigger API lookups.
* The REST endpoint is never cached and is not linked from your pages, so it adds nothing to crawl budget or your sitemap.

= Privacy by design =

* The script waits for consent to statistics or marketing cookies. It detects Complianz, Cookiebot, iubenda, CookieYes and CookieLawInfo, or you can use a custom consent cookie.
* IP addresses are never stored in clear text: only a salted hash is kept, for 30 days, to avoid repeated lookups.
* Only visits from company networks are stored. Visits from private connections are discarded.
* Configurable data retention (180 days by default) and per-company deletion.
* Suggested text for your privacy policy is added to Settings → Privacy → Policy Guide.
* The plugin identifies organizations, not people.

= What to expect =

Reverse IP lookup only works when visitors browse from a company network. People working from home or on mobile connections cannot be identified. With the free IPinfo Lite plan, only organizations that own their network (an ASN), typically medium and large companies, are recognized. Paid IPinfo plans with company data also recognize many smaller businesses: switch the plan in the settings and the plugin uses the extra data automatically.

= For developers =

* `b2bvi_lookup` filter: plug in another reverse IP provider.
* `b2bvi_new_company` action: send new companies to your CRM.
* `b2bvi_enrich_paths` filter: change the pages checked during contact enrichment.

Developed by [Agenzia Grafica Milano](https://www.agenziagraficamilano.it/sviluppo-siti-wordpress-milano/).

== External services ==

This plugin connects to third-party services. Nothing is sent until you enter an API token and enable tracking in the settings.

**IPinfo (ipinfo.io)**

Used to find the organization behind a visitor's IP address. When a consenting visitor views a page and their IP address has not been looked up in the last 30 days, your server sends that IP address and your API token to `api.ipinfo.io` (Lite plan) or `ipinfo.io` (paid plans). It also does this when an administrator uses "Test lookup" in the settings.

* Terms of service: https://ipinfo.io/terms-of-service
* Privacy policy: https://ipinfo.io/privacy-policy

**Company websites (optional contact enrichment)**

This is off by default. When you enable "Contact enrichment", your server requests the home page and common contact pages (for example /contact/) of each newly identified company's own website, to read the public email address, phone number and LinkedIn page published there. No visitor data is sent in these requests. The terms and privacy policy of each website apply.

**LinkedIn**

The "Find people" link in a company's detail page opens a LinkedIn search for the company name in your browser. The plugin itself never sends any data to LinkedIn.

== Installation ==

1. Install and activate the plugin from **Plugins → Add New**.
2. Create a free token at https://ipinfo.io/signup.
3. Go to **B2B Visitors → Settings**, paste the token and click **Test lookup** with 8.8.8.8.
4. Add your office IP to **Excluded IPs** and set your **Hot pages**.
5. Enable tracking, save and clear your page cache.
6. Update your privacy and cookie policy (suggested text in Settings → Privacy → Policy Guide).

== Frequently Asked Questions ==

= Is it really free? =

Yes. The plugin is free and open source (GPL). It works with the free IPinfo Lite plan. A paid IPinfo plan is optional and only increases how many companies are recognized.

= Does it slow down my site? =

No. The front-end script is about 1.6 KB gzipped, deferred and render-free, so it does not affect Core Web Vitals. Lookups run on the server after the page has loaded.

= Is it safe for SEO? =

Yes. It does not change your pages, markup or URLs, and crawlers see the same content as visitors.

= Is this GDPR compliant? =

The plugin is built to support compliance: it waits for cookie consent, does not store raw IP addresses, only keeps company-level data and deletes it automatically. Compliance also depends on your consent banner, your privacy policy and your legal basis, so please check with your legal advisor.

= Why are only a few companies identified? =

Most traffic comes from home, mobile and internet-provider connections, which cannot be tied to a company, so a low match rate is normal. Paid IPinfo plans recognize more companies.

= Does it work with page caching? =

Yes. Tracking runs through a small REST API call that is never cached, so it works with WP Rocket, LiteSpeed Cache, W3 Total Cache and similar plugins.

= My cookie banner is not detected. =

Choose "Custom cookie" in the settings and enter the name of the cookie your banner sets when the visitor accepts statistics cookies.

= Does it identify individual people? =

No. It identifies the organization that owns the network the visitor is connected from.

== Screenshots ==

1. Companies dashboard with interest score.
2. Company detail with sessions and pages viewed.
3. Settings.

== Changelog ==

= 1.0.0 =
* First public release.

== Upgrade Notice ==

= 1.0.0 =
First public release.
