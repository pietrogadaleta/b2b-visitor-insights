# B2B Visitor Insights — come pubblicarlo

## Contenuto del pacchetto

| Cartella | Cosa contiene | Dove va |
|---|---|---|
| `1-plugin/` | Lo zip del plugin | Va caricato su wordpress.org e allegato alla release su GitHub |
| `2-wordpress-org/assets/` | Icona, banner e 3 screenshot | Vanno nella cartella `/assets` del repository SVN di wordpress.org, dopo l'approvazione |
| `2-wordpress-org/readme.txt` | La descrizione della pagina su wordpress.org | È già dentro lo zip. Questa copia serve solo da riferimento |
| `3-github/b2b-visitor-insights/` | Il repository GitHub pronto: codice, README.md, LICENSE e immagini | Va caricato su GitHub |
| `4-traduzione-italiana/` | I file .po, .mo e .pot | Vanno su translate.wordpress.org oppure in `/wp-content/languages/plugins/` |

## wordpress.org

1. Crea l'account su https://login.wordpress.org/register e attiva la verifica in due passaggi.
2. Nel `readme.txt` sostituisci `YOUR-WPORG-USERNAME` con il tuo nome utente, poi rifai lo zip. In alternativa, dimmi il nome utente e lo faccio io.
3. Invia lo zip da https://wordpress.org/plugins/developers/add/
4. Aspetta l'email del team di revisione (di solito 1–4 settimane) e rispondi alle eventuali richieste.
5. Dopo l'approvazione ricevi l'accesso SVN: carica il codice in `/trunk`, crea il tag `/tags/1.0.0` e metti la grafica in `/assets`.

## GitHub

1. Crea il repository su https://github.com/new
   - Nome: `b2b-visitor-insights`
   - Visibilità: Public
   - Non aggiungere README né licenza, perché sono già nel pacchetto.
2. Carica il contenuto di `3-github/b2b-visitor-insights/`: trascina i file con "uploading an existing file", oppure usa git.
3. Nella sezione **About** del repository (icona dell'ingranaggio) inserisci:
   - Description: `Know which companies visit your site — no SaaS, your data stays in WordPress. Free WordPress plugin for B2B visitor identification.`
   - Website: `https://www.agenziagraficamilano.it/sviluppo-siti-wordpress-milano/`
   - Topics: `wordpress` `wordpress-plugin` `b2b` `lead-generation` `reverse-ip` `visitor-identification` `ipinfo` `gdpr`
4. Crea la release su **Releases → Draft a new release**:
   - Tag: `v1.0.0`
   - Titolo: `B2B Visitor Insights 1.0.0`
   - Allegato: `1-plugin/b2b-visitor-insights-1.0.0.zip`
   - Testo: `First public release.`
