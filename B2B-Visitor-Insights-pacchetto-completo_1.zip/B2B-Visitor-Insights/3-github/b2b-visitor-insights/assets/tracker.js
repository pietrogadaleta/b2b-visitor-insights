/**
 * B2B Visitor Insights – front-end tracker.
 * Sends nothing until the visitor has consented to statistics or marketing cookies.
 */
(function () {
	'use strict';
	var C = window.B2BVI;
	if (!C || !C.endpoint || !window.fetch || !window.JSON) {
		return;
	}

	var started = false, hid = 0, t0 = Date.now(), cachedSid = null;

	function cookie(name) {
		var m = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '=([^;]*)'));
		return m ? decodeURIComponent(m[1]) : null;
	}

	function hasConsent() {
		if (C.consent === 'none') {
			return true;
		}
		if (C.consent === 'cookie') {
			var v = C.cookie ? cookie(C.cookie) : null;
			return v !== null && !/^(0|false|no|deny|denied|rejected)$/i.test(v);
		}
		try {
			// Cookiebot.
			if (window.Cookiebot && window.Cookiebot.consent) {
				return !!(window.Cookiebot.consent.statistics || window.Cookiebot.consent.marketing);
			}
			// Complianz.
			if (typeof window.cmplz_has_consent === 'function') {
				return window.cmplz_has_consent('statistics') || window.cmplz_has_consent('marketing');
			}
			// CookieYes.
			var cy = cookie('cookieyes-consent');
			if (cy) {
				return /analytics:yes|advertisement:yes/.test(cy);
			}
			// iubenda (purpose 4 = measurement, 5 = marketing).
			var iub = document.cookie.match(/_iub_cs-[^=]+=([^;]+)/);
			if (iub) {
				var o = JSON.parse(decodeURIComponent(iub[1]));
				if (o.purposes) {
					return !!(o.purposes['4'] || o.purposes['5']);
				}
				return !!o.consent;
			}
			// CookieLawInfo / CookieYes legacy.
			var cli = cookie('cookielawinfo-checkbox-analytics');
			if (cli) {
				return cli === 'yes';
			}
		} catch (e) {}
		return false;
	}

	function sid() {
		if (cachedSid) {
			return cachedSid;
		}
		try {
			cachedSid = sessionStorage.getItem('b2bvi_sid');
		} catch (e) {}
		if (!cachedSid) {
			cachedSid = (Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2)).slice(0, 32);
			try {
				sessionStorage.setItem('b2bvi_sid', cachedSid);
			} catch (e) {}
		}
		return cachedSid;
	}

	function utm() {
		var q = new URLSearchParams(location.search), out = [];
		['utm_source', 'utm_medium', 'utm_campaign'].forEach(function (k) {
			if (q.get(k)) {
				out.push(k.replace('utm_', '') + '=' + q.get(k));
			}
		});
		return out.join('&');
	}

	function post(path, data, beacon) {
		var body = JSON.stringify(data);
		if (beacon && navigator.sendBeacon) {
			navigator.sendBeacon(C.endpoint + path, new Blob([body], { type: 'application/json' }));
			return null;
		}
		return fetch(C.endpoint + path, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			credentials: 'omit',
			keepalive: true,
			body: body
		});
	}

	function start() {
		if (started) {
			return true;
		}
		if (!hasConsent()) {
			return false;
		}
		started = true;
		post('hit', {
			sid: sid(),
			url: location.href.split('#')[0],
			title: (document.title || '').slice(0, 250),
			ref: document.referrer || '',
			utm: utm()
		}).then(function (r) {
			return r.json();
		}).then(function (j) {
			hid = (j && j.hid) || 0;
		}).catch(function () {});
		return true;
	}

	document.addEventListener('visibilitychange', function () {
		if (document.visibilityState === 'hidden' && hid) {
			post('dur', { hid: hid, sid: sid(), dur: Math.round((Date.now() - t0) / 1000) }, true);
		}
	});

	if (!start()) {
		var retry = function () {
			setTimeout(start, 300);
		};
		['CookiebotOnAccept', 'cmplz_status_change', 'cmplz_fire_categories', 'cookieyes_consent_update'].forEach(function (e) {
			window.addEventListener(e, retry);
			document.addEventListener(e, retry);
		});
		var n = 0, iv = setInterval(function () {
			if (start() || ++n > 90) {
				clearInterval(iv);
			}
		}, 2000);
	}
})();
