<p align="center">
  <img src=".github/images/banner-1544x500.png" alt="B2B Visitor Insights" width="100%">
</p>

# B2B Visitor Insights

🇮🇹 [Versione italiana](README.it.md)

**Know which companies visit your site — no SaaS, your data stays in WordPress.**

A free, self-hosted WordPress plugin for B2B visitor identification. It finds the organization behind each visit (reverse IP lookup), shows which pages every company read and scores how interested it looks. You get an email when a new company shows up. All data is stored in your own WordPress database.

All you need is a **free [IPinfo](https://ipinfo.io/signup) API token**.

![License: GPL v2+](https://img.shields.io/badge/license-GPLv2%2B-blue) ![WordPress 6.3+](https://img.shields.io/badge/WordPress-6.3%2B-21759b) ![PHP 7.4+](https://img.shields.io/badge/PHP-7.4%2B-777bb4)

## Why

Most visitor identification tools for WordPress are just a connector: they add a script, send your visitors' data to the vendor and show the results in a paid external dashboard. B2B Visitor Insights works the other way round:

- **No SaaS, no subscription:** the dashboard is in your WordPress admin.
- **Your data stays in WordPress:** only the IP address is sent to IPinfo for the lookup.
- **Free:** works with the free IPinfo Lite plan.
- **Respects your cookie banner:** nothing is tracked before consent.
- **No impact on Core Web Vitals:** a single deferred script of about 1.6 KB gzipped.
- **SEO and GEO friendly:** no changes to your pages; search engine and AI crawlers see the same content as visitors.

## Features

- Companies dashboard with sessions, page views, last visit and an interest score (High / Medium / Low)
- "Hot pages" (pricing, contact, services) that raise the score
- Company timeline: sessions, pages, time on page, referrer and UTM parameters
- Email alert for every new company
- Optional contact enrichment: public email, phone and LinkedIn page from the company's own website
- CSV export
- Consent detection for Complianz, Cookiebot, iubenda, CookieYes and CookieLawInfo, or a custom cookie
- Salted IP hashing, automatic data retention and per-company deletion
- Fully translatable (Italian included)

## Screenshots

| Companies | Company detail | Settings |
|---|---|---|
| ![Companies](.github/images/screenshot-1.png) | ![Company detail](.github/images/screenshot-2.png) | ![Settings](.github/images/screenshot-3.png) |

## Installation

1. Download the latest release ZIP from [Releases](../../releases) and upload it in **Plugins → Add New → Upload Plugin**, or install it from the WordPress.org plugin directory.
2. Create a free token at [ipinfo.io/signup](https://ipinfo.io/signup).
3. Go to **B2B Visitors → Settings**, paste the token and click **Test lookup** with `8.8.8.8`. The result should be "Google LLC – discarded".
4. Add your office IP to **Excluded IPs** and set your **Hot pages**, for example `contact,pricing,quote,services`.
5. Enable tracking, save and clear your page cache.
6. Update your privacy and cookie policy (suggested text in **Settings → Privacy → Policy Guide**).

If your site is behind the Cloudflare proxy and the "current IP" shown in the settings is a Cloudflare address, set **Real IP header** to `CF-Connecting-IP`.

## What to expect

Reverse IP lookup only works for visits from company networks. Home and mobile connections cannot be identified and are discarded. With the free IPinfo Lite plan, mostly medium and large companies (organizations with their own network) are recognized. Paid IPinfo plans with company data also recognize many smaller businesses.

## For developers

```php
// Use another reverse IP provider.
add_filter( 'b2bvi_lookup', function ( $result, $ip ) {
	return array( 'name' => 'Acme Inc.', 'domain' => 'acme.example', 'type' => 'business', 'country' => 'IT' );
}, 10, 2 );

// Send new companies to your CRM.
add_action( 'b2bvi_new_company', function ( $company_id, $data ) {
	// ...
}, 10, 2 );

// Pages checked during contact enrichment.
add_filter( 'b2bvi_enrich_paths', fn( $paths ) => array_merge( $paths, array( '/about/' ) ) );
```

## External services

This plugin sends the visitor's IP address to [IPinfo](https://ipinfo.io) ([terms](https://ipinfo.io/terms-of-service), [privacy](https://ipinfo.io/privacy-policy)), and only after consent. Optional contact enrichment requests public pages of the identified company's own website. See `readme.txt` for details.

## License

GPLv2 or later. See [LICENSE](LICENSE).

---

Developed by [Agenzia Grafica Milano](https://www.agenziagraficamilano.it/sviluppo-siti-wordpress-milano/).
