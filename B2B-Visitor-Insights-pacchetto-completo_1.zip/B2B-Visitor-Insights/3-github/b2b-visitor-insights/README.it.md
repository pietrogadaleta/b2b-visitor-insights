<p align="center">
  <img src=".github/images/banner-1544x500.png" alt="B2B Visitor Insights" width="100%">
</p>

# B2B Visitor Insights

🇬🇧 [English version](README.md)

**Scopri quali aziende visitano il tuo sito: niente SaaS, i tuoi dati restano in WordPress.**

B2B Visitor Insights è un plugin WordPress gratuito che identifica le aziende che visitano il tuo sito. Risale all'azienda dietro ogni visita con un lookup inverso dell'IP, ti mostra quali pagine ha letto ogni azienda e stima quanto è interessata. Ti avvisa via email quando arriva una nuova azienda. Tutti i dati restano nel database del tuo WordPress.

Ti serve solo un **token API gratuito di [IPinfo](https://ipinfo.io/signup)**.

![Licenza: GPL v2+](https://img.shields.io/badge/license-GPLv2%2B-blue) ![WordPress 6.3+](https://img.shields.io/badge/WordPress-6.3%2B-21759b) ![PHP 7.4+](https://img.shields.io/badge/PHP-7.4%2B-777bb4)

## Perché sceglierlo

Quasi tutti i plugin di identificazione dei visitatori per WordPress sono solo un collegamento: aggiungono uno script, inviano i dati dei tuoi visitatori al fornitore e ti mostrano i risultati in una dashboard esterna a pagamento. B2B Visitor Insights funziona al contrario:

- **Niente SaaS, niente abbonamento:** la dashboard è nel pannello di WordPress.
- **I dati restano in WordPress:** a IPinfo viene inviato solo l'indirizzo IP, per il lookup.
- **Gratuito:** funziona con il piano gratuito IPinfo Lite.
- **Rispetta il cookie banner:** non traccia nulla prima del consenso.
- **Nessun impatto sui Core Web Vitals:** un solo script di circa 1,6 KB compresso, caricato in differita.
- **Compatibile con SEO e GEO:** non modifica le pagine, e i crawler dei motori di ricerca e delle AI vedono lo stesso contenuto dei visitatori.

## Funzioni

- Dashboard delle aziende con sessioni, pagine viste, ultima visita e punteggio di interesse (Alta / Media / Bassa)
- "Pagine calde" (prezzi, contatti, servizi) che aumentano il punteggio
- Cronologia di ogni azienda: sessioni, pagine, tempo di permanenza, provenienza e parametri UTM
- Avviso via email per ogni nuova azienda
- Recupero contatti facoltativo: email, telefono e pagina LinkedIn pubblici, presi dal sito dell'azienda
- Export CSV
- Riconoscimento del consenso per Complianz, Cookiebot, iubenda, CookieYes e CookieLawInfo, oppure tramite un cookie personalizzato
- IP salvati solo come hash, cancellazione automatica dei dati ed eliminazione per singola azienda
- Completamente traducibile (italiano incluso)

## Screenshot

| Aziende | Scheda azienda | Impostazioni |
|---|---|---|
| ![Aziende](.github/images/screenshot-1.png) | ![Scheda azienda](.github/images/screenshot-2.png) | ![Impostazioni](.github/images/screenshot-3.png) |

## Installazione

1. Scarica lo zip dell'ultima versione dalla sezione [Releases](../../releases) e caricalo da **Plugin → Aggiungi nuovo → Carica plugin**, oppure installalo dalla directory plugin di WordPress.org.
2. Crea un token gratuito su [ipinfo.io/signup](https://ipinfo.io/signup).
3. Vai su **Visitatori B2B → Impostazioni**, incolla il token e clicca **Prova lookup** con `8.8.8.8`. Deve uscire "Google LLC – scartato".
4. Aggiungi l'IP del tuo ufficio in **IP esclusi** e imposta le **Pagine calde**, per esempio `contatti,prezzi,preventivo,servizi`.
5. Attiva il tracciamento, salva e svuota la cache del sito.
6. Aggiorna privacy e cookie policy. Trovi un testo suggerito in **Impostazioni → Privacy → Guida alla policy**.

Se il sito è dietro il proxy di Cloudflare e l'"IP attuale" mostrato nelle impostazioni è un indirizzo di Cloudflare, imposta **Header IP reale** su `CF-Connecting-IP`.

## Cosa aspettarsi

Il lookup inverso dell'IP funziona solo per le visite da reti aziendali. Le connessioni da casa e da mobile non si possono identificare e vengono scartate. Con il piano gratuito IPinfo Lite vengono riconosciute soprattutto le medie e grandi aziende, cioè quelle con una rete propria. I piani IPinfo a pagamento con dati aziendali riconoscono anche molte PMI.

## Per sviluppatori

```php
// Usa un altro provider di reverse IP.
add_filter( 'b2bvi_lookup', function ( $result, $ip ) {
	return array( 'name' => 'Acme Srl', 'domain' => 'acme.example', 'type' => 'business', 'country' => 'IT' );
}, 10, 2 );

// Invia le nuove aziende al tuo CRM.
add_action( 'b2bvi_new_company', function ( $company_id, $data ) {
	// ...
}, 10, 2 );

// Pagine controllate durante il recupero contatti.
add_filter( 'b2bvi_enrich_paths', fn( $paths ) => array_merge( $paths, array( '/chi-siamo/' ) ) );
```

## Servizi esterni

Il plugin invia l'indirizzo IP del visitatore a [IPinfo](https://ipinfo.io) ([termini](https://ipinfo.io/terms-of-service), [privacy](https://ipinfo.io/privacy-policy)), e solo dopo il consenso. Il recupero contatti facoltativo visita alcune pagine pubbliche del sito dell'azienda identificata. I dettagli sono in `readme.txt`.

## Licenza

GPLv2 o successiva. Vedi [LICENSE](LICENSE).

---

Sviluppato da [Agenzia Grafica Milano](https://www.agenziagraficamilano.it/sviluppo-siti-wordpress-milano/).
