<?php
/**
 * Plugin Name:       B2B Visitor Insights
 * Description:       See which companies visit your website (reverse IP lookup), which pages they viewed, and get notified about new B2B leads. GDPR-minded: consent-aware, no raw IPs stored.
 * Version:           1.0.0
 * Requires at least: 6.3
 * Requires PHP:      7.4
 * Author:            Agenzia Grafica Milano
 * Author URI:        https://www.agenziagraficamilano.it/sviluppo-siti-wordpress-milano/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       b2b-visitor-insights
 *
 * @package B2B_Visitor_Insights
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'B2BVI_VER', '1.0.0' );
define( 'B2BVI_FILE', __FILE__ );
define( 'B2BVI_DIR', plugin_dir_path( __FILE__ ) );
define( 'B2BVI_URL', plugin_dir_url( __FILE__ ) );

require_once B2BVI_DIR . 'includes/class-b2bvi-db.php';
require_once B2BVI_DIR . 'includes/class-b2bvi-lookup.php';
require_once B2BVI_DIR . 'includes/class-b2bvi-tracker.php';
require_once B2BVI_DIR . 'includes/class-b2bvi-cron.php';
require_once B2BVI_DIR . 'includes/class-b2bvi-admin.php';

/**
 * Default settings.
 *
 * @return array
 */
function b2bvi_defaults() {
	return array(
		'enabled'        => 0,
		'ipinfo_token'   => '',
		'ipinfo_plan'    => 'lite',
		'consent_mode'   => 'auto',
		'consent_cookie' => '',
		'ip_header'      => '',
		'exclude_ips'    => '',
		'isp_extra'      => '',
		'hot_pages'      => 'contact,pricing,quote,services',
		'enrich'         => 0,
		'notify_email'   => get_option( 'admin_email' ),
		'retention_days' => 180,
	);
}

/**
 * Read a single setting.
 *
 * @param string $key     Setting key.
 * @param mixed  $fallback Value returned when the key does not exist.
 * @return mixed
 */
function b2bvi_opt( $key, $fallback = null ) {
	$o = wp_parse_args( (array) get_option( 'b2bvi_settings', array() ), b2bvi_defaults() );
	return array_key_exists( $key, $o ) ? $o[ $key ] : $fallback;
}

register_activation_hook( __FILE__, array( 'B2BVI_DB', 'install' ) );
register_deactivation_hook( __FILE__, array( 'B2BVI_Cron', 'deactivate' ) );

add_action(
	'plugins_loaded',
	function () {
		B2BVI_DB::maybe_upgrade();
		B2BVI_Tracker::init();
		B2BVI_Cron::init();
		if ( is_admin() ) {
			B2BVI_Admin::init();
		}
	}
);
