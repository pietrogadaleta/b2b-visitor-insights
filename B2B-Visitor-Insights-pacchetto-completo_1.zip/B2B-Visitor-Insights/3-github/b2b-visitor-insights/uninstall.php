<?php
/**
 * Remove all plugin data on uninstall.
 *
 * @package B2B_Visitor_Insights
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;
foreach ( array( 'visits', 'ip_cache', 'companies' ) as $b2bvi_table ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Dropping the plugin's own tables.
	$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . 'b2bvi_' . $b2bvi_table ) );
}
delete_option( 'b2bvi_settings' );
delete_option( 'b2bvi_stats' );
delete_option( 'b2bvi_db' );
wp_clear_scheduled_hook( 'b2bvi_daily' );
wp_clear_scheduled_hook( 'b2bvi_enrich' );
wp_clear_scheduled_hook( 'b2bvi_notify' );
