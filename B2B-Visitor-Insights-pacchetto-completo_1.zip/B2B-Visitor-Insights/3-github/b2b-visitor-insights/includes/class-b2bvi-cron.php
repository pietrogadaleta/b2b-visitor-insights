<?php
/**
 * Background jobs: enrichment, notifications, data retention.
 *
 * @package B2B_Visitor_Insights
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery -- Custom plugin tables; results are not cacheable.

/**
 * Scheduled tasks.
 */
class B2BVI_Cron {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'b2bvi_enrich', array( __CLASS__, 'enrich' ) );
		add_action( 'b2bvi_notify', array( __CLASS__, 'notify' ) );
		add_action( 'b2bvi_daily', array( __CLASS__, 'daily' ) );
	}

	/**
	 * Clear scheduled events on deactivation.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'b2bvi_daily' );
		wp_clear_scheduled_hook( 'b2bvi_enrich' );
		wp_clear_scheduled_hook( 'b2bvi_notify' );
	}

	/**
	 * Get a company row.
	 *
	 * @param int $id Company id.
	 * @return object|null
	 */
	private static function company( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', B2BVI_DB::t( 'companies' ), $id ) );
	}

	/**
	 * Read public contact details (email, phone, LinkedIn) from the company's own website.
	 * Runs only when the "Contact enrichment" setting is enabled.
	 *
	 * @param int $id Company id.
	 */
	public static function enrich( $id ) {
		global $wpdb;
		if ( ! b2bvi_opt( 'enrich', 0 ) ) {
			return;
		}
		$c = self::company( $id );
		if ( ! $c || ! $c->domain ) {
			return;
		}
		$f = array(
			'email'    => '',
			'phone'    => '',
			'linkedin' => '',
		);

		/**
		 * Paths checked on the company website.
		 *
		 * @param string[] $paths Paths.
		 */
		$paths = apply_filters( 'b2bvi_enrich_paths', array( '/', '/contact/', '/contacts/', '/contatti/', '/kontakt/', '/contacto/' ) );

		foreach ( (array) $paths as $path ) {
			$res = wp_safe_remote_get(
				'https://' . $c->domain . $path,
				array(
					'timeout'             => 8,
					'redirection'         => 3,
					'limit_response_size' => 800000,
					'user-agent'          => 'B2B Visitor Insights/' . B2BVI_VER . '; ' . home_url( '/' ),
				)
			);
			if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
				continue;
			}
			$html = wp_remote_retrieve_body( $res );

			if ( ! $f['email'] ) {
				$emails = array();
				if ( preg_match_all( '/mailto:([A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,})/i', $html, $m ) ) {
					$emails = $m[1];
				} elseif ( preg_match_all( '/\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b/i', $html, $m ) ) {
					$emails = array_filter(
						$m[0],
						function ( $e ) {
							return ! preg_match( '/\.(png|jpe?g|gif|webp|svg|css|js)$/i', $e );
						}
					);
				}
				$f['email'] = self::best_email( $emails, $c->domain );
			}
			if ( ! $f['phone'] && preg_match( '/tel:([+0-9 ()\.\-%]{6,40})/i', $html, $m ) ) {
				$f['phone'] = trim( rawurldecode( $m[1] ) );
			}
			if ( ! $f['linkedin'] && preg_match( '#https?://(?:[a-z]{2,3}\.)?linkedin\.com/company/[A-Za-z0-9\-_%.]+#i', $html, $m ) ) {
				$f['linkedin'] = $m[0];
			}
			if ( $f['email'] && $f['phone'] && $f['linkedin'] ) {
				break;
			}
		}

		$wpdb->update(
			B2BVI_DB::t( 'companies' ),
			array(
				'email'       => substr( sanitize_email( $f['email'] ), 0, 190 ),
				'phone'       => substr( sanitize_text_field( $f['phone'] ), 0, 60 ),
				'linkedin'    => substr( esc_url_raw( $f['linkedin'] ), 0, 255 ),
				'enriched_at' => current_time( 'mysql', true ),
			),
			array( 'id' => (int) $id )
		);
	}

	/**
	 * Pick the most useful generic address.
	 *
	 * @param string[] $emails Candidates.
	 * @param string   $domain Company domain.
	 * @return string
	 */
	private static function best_email( $emails, $domain ) {
		$emails = array_values( array_unique( array_map( 'strtolower', (array) $emails ) ) );
		if ( ! $emails ) {
			return '';
		}
		$base  = preg_replace( '/^www\./', '', $domain );
		$score = function ( $e ) use ( $base ) {
			$s = 0;
			if ( false !== strpos( $e, '@' . $base ) ) {
				$s += 10;
			}
			if ( preg_match( '/^(info|sales|contact|hello|office|commerciale|vendite|marketing|contatti)@/', $e ) ) {
				$s += 5;
			}
			return $s;
		};
		usort(
			$emails,
			function ( $a, $b ) use ( $score ) {
				return $score( $b ) - $score( $a );
			}
		);
		return $emails[0];
	}

	/**
	 * Email sent about 20 minutes after a new company's first visit.
	 *
	 * @param int $id Company id.
	 */
	public static function notify( $id ) {
		global $wpdb;
		$to = b2bvi_opt( 'notify_email', '' );
		$c  = self::company( $id );
		if ( ! $to || ! $c || $c->notified ) {
			return;
		}
		$pages = $wpdb->get_results( $wpdb->prepare( 'SELECT url, title, duration, created FROM %i WHERE company_id = %d ORDER BY created ASC LIMIT 40', B2BVI_DB::t( 'visits' ), $id ) );

		/* translators: %s: company name. */
		$lines = array( sprintf( __( 'New company on your website: %s', 'b2b-visitor-insights' ), $c->name ), '' );
		if ( $c->domain ) {
			/* translators: %s: website URL. */
			$lines[] = sprintf( __( 'Website: %s', 'b2b-visitor-insights' ), 'https://' . $c->domain );
		}
		$loc = trim( $c->city . ( $c->country ? ' (' . $c->country . ')' : '' ) );
		if ( $loc ) {
			/* translators: %s: city and country. */
			$lines[] = sprintf( __( 'Location: %s', 'b2b-visitor-insights' ), $loc );
		}
		if ( $c->email ) {
			/* translators: %s: email address. */
			$lines[] = sprintf( __( 'Email: %s', 'b2b-visitor-insights' ), $c->email );
		}
		if ( $c->phone ) {
			/* translators: %s: phone number. */
			$lines[] = sprintf( __( 'Phone: %s', 'b2b-visitor-insights' ), $c->phone );
		}
		if ( $c->linkedin ) {
			$lines[] = 'LinkedIn: ' . $c->linkedin;
		}
		$lines[] = '';
		$lines[] = __( 'Pages viewed:', 'b2b-visitor-insights' );
		foreach ( $pages as $p ) {
			$path    = wp_parse_url( $p->url, PHP_URL_PATH );
			$lines[] = '- ' . get_date_from_gmt( $p->created, 'H:i' ) . '  ' . ( $path ? $path : '/' ) . ( $p->duration ? '  (' . (int) $p->duration . 's)' : '' );
		}
		$lines[] = '';
		/* translators: %s: admin URL. */
		$lines[] = sprintf( __( 'Details: %s', 'b2b-visitor-insights' ), admin_url( 'admin.php?page=b2bvi&company=' . (int) $id ) );

		/* translators: %s: company name. */
		$subject = sprintf( __( '[B2B Visitors] %s visited your website', 'b2b-visitor-insights' ), $c->name );
		wp_mail( $to, $subject, implode( "\n", $lines ) );
		$wpdb->update( B2BVI_DB::t( 'companies' ), array( 'notified' => 1 ), array( 'id' => (int) $id ) );
	}

	/**
	 * Data retention.
	 */
	public static function daily() {
		global $wpdb;
		$days  = max( 7, (int) b2bvi_opt( 'retention_days', 180 ) );
		$limit = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$vt    = B2BVI_DB::t( 'visits' );
		$ct    = B2BVI_DB::t( 'companies' );
		$it    = B2BVI_DB::t( 'ip_cache' );

		$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE created < %s', $vt, $limit ) );
		$old = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE last_seen < %s', $ct, $limit ) );
		foreach ( $old as $cid ) {
			$wpdb->delete( $it, array( 'company_id' => (int) $cid ) );
			$wpdb->delete( $ct, array( 'id' => (int) $cid ) );
		}
		$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE checked_at < %s', $it, gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ) );
	}
}
