<?php
/**
 * Reverse IP lookup (IP -> organization).
 *
 * @package B2B_Visitor_Insights
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves an IP address to an organization.
 *
 * Default provider: IPinfo (free Lite plan returns ASN data; paid plans return company data).
 * Other providers can be plugged in with the 'b2bvi_lookup' filter, returning an array with
 * the keys name, domain, type, asn, city, region, country.
 */
class B2BVI_Lookup {

	/**
	 * Internet providers, telcos, clouds and VPNs that never identify a company.
	 */
	const ISP = 'telecom italia|\btim\b|vodafone|fastweb|wind ?tre|wind telecomunicazioni|iliad|tiscali|eolo|linkem|open ?fiber|sky italia|aruba|ovh|amazon|\baws\b|google|microsoft|cloudflare|digitalocean|hetzner|akamai|fastly|oracle|leaseweb|contabo|ionos|1&1|register\.it|seeweb|irideos|retelit|\bcolt\b|orange|deutsche telekom|telefonica|comcast|verizon|at&t|t-mobile|charter|cox communications|starlink|space exploration|apple|facebook|meta platforms|m247|datacamp|choopa|vultr|linode|ehiweb|sinergy|planetel|convergenze|tecnoadsl|vianova|uno communications|clouditalia|mc-link|bt italia|level 3|lumen|zscaler|nordvpn|mullvad|proton|telenet|swisscom|free sas|bouygues|\bsfr\b|\bkpn\b|ziggo|virgin media|british telecommunications|\bsky uk\b|telia|telstra|rogers|bell canada|shaw|reliance jio|bharti|china telecom|china unicom|china mobile';

	/**
	 * Regex that matches ISP/hosting names.
	 *
	 * @return string
	 */
	public static function isp_regex() {
		$extra = array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', (string) b2bvi_opt( 'isp_extra', '' ) ) ) );
		$extra = array_map(
			function ( $s ) {
				return preg_quote( $s, '/' );
			},
			$extra
		);
		return '/(' . self::ISP . ( $extra ? '|' . implode( '|', $extra ) : '' ) . ')/i';
	}

	/**
	 * Look up an IP address.
	 *
	 * @param string $ip IP address.
	 * @return array|null Null on API error (the result must not be cached).
	 */
	public static function lookup( $ip ) {
		/**
		 * Short-circuit the lookup with a custom provider.
		 *
		 * @param array|null $result Null to use IPinfo, or an array describing the organization.
		 * @param string     $ip     Visitor IP address.
		 */
		$custom = apply_filters( 'b2bvi_lookup', null, $ip );
		if ( is_array( $custom ) ) {
			return self::classify( $custom );
		}

		$token = b2bvi_opt( 'ipinfo_token', '' );
		if ( ! $token ) {
			return null;
		}

		$url = 'lite' === b2bvi_opt( 'ipinfo_plan', 'lite' )
			? 'https://api.ipinfo.io/lite/' . rawurlencode( $ip )
			: 'https://ipinfo.io/' . rawurlencode( $ip ) . '/json';

		$res = wp_remote_get(
			$url,
			array(
				'timeout' => 4,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Accept'        => 'application/json',
				),
			)
		);
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			return null;
		}
		$j = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $j ) ) {
			return null;
		}

		$country = '';
		if ( ! empty( $j['country_code'] ) ) {
			$country = $j['country_code'];
		} elseif ( ! empty( $j['country'] ) && strlen( $j['country'] ) <= 3 ) {
			$country = $j['country'];
		}

		$o = array(
			'name'    => '',
			'domain'  => '',
			'asn'     => '',
			'type'    => '',
			'city'    => isset( $j['city'] ) ? $j['city'] : '',
			'region'  => isset( $j['region'] ) ? $j['region'] : '',
			'country' => $country,
		);

		if ( ! empty( $j['company']['name'] ) ) {
			// Business / Enterprise plans.
			$o['name']   = $j['company']['name'];
			$o['domain'] = isset( $j['company']['domain'] ) ? $j['company']['domain'] : '';
			$o['type']   = isset( $j['company']['type'] ) ? $j['company']['type'] : '';
		} elseif ( ! empty( $j['as_name'] ) ) {
			// Lite plan.
			$o['name']   = $j['as_name'];
			$o['domain'] = isset( $j['as_domain'] ) ? $j['as_domain'] : '';
			$o['asn']    = isset( $j['asn'] ) && is_string( $j['asn'] ) ? $j['asn'] : '';
		} elseif ( ! empty( $j['asn']['name'] ) ) {
			// Core / Plus plans.
			$o['name']   = $j['asn']['name'];
			$o['domain'] = isset( $j['asn']['domain'] ) ? $j['asn']['domain'] : '';
			$o['asn']    = isset( $j['asn']['asn'] ) ? $j['asn']['asn'] : '';
			$o['type']   = isset( $j['asn']['type'] ) ? $j['asn']['type'] : '';
		} elseif ( ! empty( $j['org'] ) ) {
			// Legacy format "AS123 Name".
			if ( preg_match( '/^(AS\d+)\s+(.*)$/', $j['org'], $m ) ) {
				$o['asn']  = $m[1];
				$o['name'] = $m[2];
			} else {
				$o['name'] = $j['org'];
			}
		}

		if ( ! empty( $j['privacy']['hosting'] ) || ! empty( $j['privacy']['vpn'] ) || ! empty( $j['privacy']['proxy'] ) ) {
			$o['type'] = 'hosting';
		}

		return self::classify( $o );
	}

	/**
	 * Normalize a lookup result and flag ISPs.
	 *
	 * @param array $o Raw result.
	 * @return array
	 */
	public static function classify( $o ) {
		$o           = wp_parse_args(
			$o,
			array(
				'name'    => '',
				'domain'  => '',
				'asn'     => '',
				'type'    => '',
				'city'    => '',
				'region'  => '',
				'country' => '',
			)
		);
		$type        = strtolower( (string) $o['type'] );
		$o['is_isp'] = ( '' === trim( (string) $o['name'] ) )
			|| in_array( $type, array( 'isp', 'hosting' ), true )
			|| (bool) preg_match( self::isp_regex(), $o['name'] . ' ' . $o['domain'] );
		return $o;
	}
}
