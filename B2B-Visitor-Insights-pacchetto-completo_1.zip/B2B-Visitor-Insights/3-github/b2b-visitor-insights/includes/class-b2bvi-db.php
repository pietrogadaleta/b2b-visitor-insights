<?php
/**
 * Database schema.
 *
 * @package B2B_Visitor_Insights
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates and upgrades the plugin tables.
 */
class B2BVI_DB {

	const VER = '1';

	/**
	 * Full table name.
	 *
	 * @param string $name Short name.
	 * @return string
	 */
	public static function t( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'b2bvi_' . $name;
	}

	/**
	 * Create tables and default options.
	 */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();

		dbDelta(
			'CREATE TABLE ' . self::t( 'companies' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			ckey varchar(190) NOT NULL,
			name varchar(255) NOT NULL DEFAULT '',
			domain varchar(190) NOT NULL DEFAULT '',
			asn varchar(20) NOT NULL DEFAULT '',
			city varchar(100) NOT NULL DEFAULT '',
			region varchar(100) NOT NULL DEFAULT '',
			country varchar(10) NOT NULL DEFAULT '',
			phone varchar(60) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			linkedin varchar(255) NOT NULL DEFAULT '',
			sessions int(10) unsigned NOT NULL DEFAULT 0,
			pageviews int(10) unsigned NOT NULL DEFAULT 0,
			first_seen datetime NOT NULL,
			last_seen datetime NOT NULL,
			enriched_at datetime NULL DEFAULT NULL,
			notified tinyint(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY ckey (ckey),
			KEY last_seen (last_seen)
		) $c;"
		);

		dbDelta(
			'CREATE TABLE ' . self::t( 'ip_cache' ) . " (
			ip_hash char(64) NOT NULL,
			company_id bigint(20) unsigned NOT NULL DEFAULT 0,
			is_isp tinyint(1) NOT NULL DEFAULT 0,
			org varchar(255) NOT NULL DEFAULT '',
			checked_at datetime NOT NULL,
			PRIMARY KEY  (ip_hash),
			KEY company_id (company_id)
		) $c;"
		);

		dbDelta(
			'CREATE TABLE ' . self::t( 'visits' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			company_id bigint(20) unsigned NOT NULL,
			sid varchar(40) NOT NULL DEFAULT '',
			url varchar(500) NOT NULL DEFAULT '',
			title varchar(255) NOT NULL DEFAULT '',
			referrer varchar(500) NOT NULL DEFAULT '',
			utm varchar(255) NOT NULL DEFAULT '',
			duration int(10) unsigned NOT NULL DEFAULT 0,
			created datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY company_created (company_id,created),
			KEY created (created)
		) $c;"
		);

		update_option( 'b2bvi_db', self::VER, false );
		if ( false === get_option( 'b2bvi_settings' ) ) {
			add_option( 'b2bvi_settings', b2bvi_defaults(), '', false );
		}
		if ( ! wp_next_scheduled( 'b2bvi_daily' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'b2bvi_daily' );
		}
	}

	/**
	 * Run install when the schema version changes.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'b2bvi_db' ) !== self::VER ) {
			self::install();
		}
	}
}
