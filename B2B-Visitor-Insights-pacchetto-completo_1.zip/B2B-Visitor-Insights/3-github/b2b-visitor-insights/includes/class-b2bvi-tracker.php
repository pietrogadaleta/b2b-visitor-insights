<?php
/**
 * Front-end tracker and REST endpoints.
 *
 * @package B2B_Visitor_Insights
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery -- Custom plugin tables; results are not cacheable.

/**
 * Collects page views from identified companies.
 */
class B2BVI_Tracker {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * Enqueue the tracker for anonymous visitors.
	 */
	public static function enqueue() {
		if ( ! b2bvi_opt( 'enabled', 0 ) || current_user_can( 'edit_posts' ) ) {
			return;
		}
		wp_enqueue_script(
			'b2bvi-tracker',
			B2BVI_URL . 'assets/tracker.js',
			array(),
			B2BVI_VER,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_localize_script(
			'b2bvi-tracker',
			'B2BVI',
			array(
				'endpoint' => esc_url_raw( rest_url( 'b2bvi/v1/' ) ),
				'consent'  => b2bvi_opt( 'consent_mode', 'auto' ),
				'cookie'   => b2bvi_opt( 'consent_cookie', '' ),
			)
		);
	}

	/**
	 * REST routes (public: they only accept page-view data for the current site).
	 */
	public static function routes() {
		register_rest_route(
			'b2bvi/v1',
			'/hit',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'hit' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			'b2bvi/v1',
			'/dur',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'dur' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Uncacheable response.
	 *
	 * @param int $hid Visit id.
	 * @return WP_REST_Response
	 */
	private static function resp( $hid = 0 ) {
		$r = new WP_REST_Response( array( 'hid' => (int) $hid ), 200 );
		$r->header( 'Cache-Control', 'no-store, private' );
		return $r;
	}

	/**
	 * Visitor IP (public addresses only).
	 *
	 * @return string
	 */
	public static function ip() {
		$cands  = array();
		$header = b2bvi_opt( 'ip_header', '' );
		if ( $header ) {
			$k = 'HTTP_' . strtoupper( str_replace( '-', '_', $header ) );
			if ( ! empty( $_SERVER[ $k ] ) ) {
				$parts   = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $k ] ) ) );
				$cands[] = trim( $parts[0] );
			}
		}
		$cands[] = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		foreach ( $cands as $ip ) {
			if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				return $ip;
			}
		}
		return '';
	}

	/**
	 * Is the IP in the exclusion list?
	 *
	 * @param string $ip IP address.
	 * @return bool
	 */
	private static function excluded( $ip ) {
		$list = array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', (string) b2bvi_opt( 'exclude_ips', '' ) ) ) );
		foreach ( $list as $e ) {
			if ( $e === $ip ) {
				return true;
			}
			if ( '*' === substr( $e, -1 ) && 0 === strpos( $ip, rtrim( $e, '*' ) ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Daily counters (total page views / page views from companies).
	 *
	 * @param string $key 't' or 'm'.
	 */
	private static function stat( $key ) {
		$s = get_option( 'b2bvi_stats', array() );
		$s = is_array( $s ) ? $s : array();
		$d = gmdate( 'Y-m-d' );
		if ( ! isset( $s[ $d ] ) ) {
			$s[ $d ] = array(
				't' => 0,
				'm' => 0,
			);
			$s       = array_slice( $s, -400, null, true );
		}
		++$s[ $d ][ $key ];
		update_option( 'b2bvi_stats', $s, false );
	}

	/**
	 * Clean a session id.
	 *
	 * @param mixed $v Raw value.
	 * @return string
	 */
	private static function clean_sid( $v ) {
		return substr( preg_replace( '/[^a-zA-Z0-9]/', '', (string) $v ), 0, 40 );
	}

	/**
	 * Record a page view.
	 *
	 * @param WP_REST_Request $req Request.
	 * @return WP_REST_Response
	 */
	public static function hit( WP_REST_Request $req ) {
		if ( ! b2bvi_opt( 'enabled', 0 ) ) {
			return self::resp();
		}
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		if ( '' === $ua || preg_match( '/bot|crawl|spider|slurp|preview|headless|lighthouse|pingdom|uptime|monitor|curl|wget|python|java\//i', $ua ) ) {
			return self::resp();
		}
		$ip = self::ip();
		if ( ! $ip || self::excluded( $ip ) ) {
			return self::resp();
		}

		$p = $req->get_json_params();
		if ( ! is_array( $p ) ) {
			return self::resp();
		}
		$url  = esc_url_raw( isset( $p['url'] ) ? (string) $p['url'] : '' );
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( ! $url || wp_parse_url( $url, PHP_URL_HOST ) !== $host ) {
			return self::resp();
		}
		$sid = self::clean_sid( isset( $p['sid'] ) ? $p['sid'] : '' );
		if ( strlen( $sid ) < 8 ) {
			return self::resp();
		}

		// The IP is never stored in clear text: only a salted hash.
		$hash = hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );

		$rk = 'b2bvi_rl_' . substr( $hash, 0, 24 );
		$n  = (int) get_transient( $rk );
		if ( $n > 120 ) {
			return self::resp();
		}
		set_transient( $rk, $n + 1, 10 * MINUTE_IN_SECONDS );

		self::stat( 't' );
		$cid = self::company_for( $ip, $hash );
		if ( ! $cid ) {
			return self::resp();
		}
		self::stat( 'm' );

		global $wpdb;
		$vt  = B2BVI_DB::t( 'visits' );
		$ct  = B2BVI_DB::t( 'companies' );
		$now = current_time( 'mysql', true );

		$new_session = ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE company_id = %d AND sid = %s LIMIT 1', $vt, $cid, $sid ) );

		$wpdb->insert(
			$vt,
			array(
				'company_id' => $cid,
				'sid'        => $sid,
				'url'        => substr( $url, 0, 500 ),
				'title'      => substr( sanitize_text_field( isset( $p['title'] ) ? (string) $p['title'] : '' ), 0, 255 ),
				'referrer'   => substr( esc_url_raw( isset( $p['ref'] ) ? (string) $p['ref'] : '' ), 0, 500 ),
				'utm'        => substr( sanitize_text_field( isset( $p['utm'] ) ? (string) $p['utm'] : '' ), 0, 255 ),
				'created'    => $now,
			)
		);
		$hid = (int) $wpdb->insert_id;

		$wpdb->query( $wpdb->prepare( 'UPDATE %i SET pageviews = pageviews + 1, sessions = sessions + %d, last_seen = %s WHERE id = %d', $ct, $new_session ? 1 : 0, $now, $cid ) );

		return self::resp( $hid );
	}

	/**
	 * Store time on page.
	 *
	 * @param WP_REST_Request $req Request.
	 * @return WP_REST_Response
	 */
	public static function dur( WP_REST_Request $req ) {
		$p   = (array) $req->get_json_params();
		$hid = absint( isset( $p['hid'] ) ? $p['hid'] : 0 );
		$sid = self::clean_sid( isset( $p['sid'] ) ? $p['sid'] : '' );
		$d   = min( absint( isset( $p['dur'] ) ? $p['dur'] : 0 ), 3600 );
		if ( $hid && $sid ) {
			global $wpdb;
			$wpdb->query( $wpdb->prepare( 'UPDATE %i SET duration = %d WHERE id = %d AND sid = %s AND duration < %d', B2BVI_DB::t( 'visits' ), $d, $hid, $sid, $d ) );
		}
		return new WP_REST_Response( null, 204 );
	}

	/**
	 * Resolve (and cache) the company behind an IP.
	 *
	 * @param string $ip   IP address.
	 * @param string $hash Hashed IP.
	 * @return int Company id, 0 if none.
	 */
	private static function company_for( $ip, $hash ) {
		global $wpdb;
		$t   = B2BVI_DB::t( 'ip_cache' );
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT company_id, checked_at FROM %i WHERE ip_hash = %s', $t, $hash ) );
		if ( $row && strtotime( $row->checked_at . ' UTC' ) > time() - 30 * DAY_IN_SECONDS ) {
			return (int) $row->company_id;
		}

		$o = B2BVI_Lookup::lookup( $ip );
		if ( null === $o ) {
			return 0; // API error: try again on the next visit.
		}

		$cid = $o['is_isp'] ? 0 : self::upsert_company( $o );
		$wpdb->replace(
			$t,
			array(
				'ip_hash'    => $hash,
				'company_id' => $cid,
				'is_isp'     => $o['is_isp'] ? 1 : 0,
				'org'        => substr( (string) $o['name'], 0, 255 ),
				'checked_at' => current_time( 'mysql', true ),
			)
		);
		return $cid;
	}

	/**
	 * Find or create a company.
	 *
	 * @param array $o Lookup result.
	 * @return int
	 */
	private static function upsert_company( $o ) {
		global $wpdb;
		$t      = B2BVI_DB::t( 'companies' );
		$domain = strtolower( trim( (string) $o['domain'] ) );
		$domain = rtrim( preg_replace( '#^https?://(www\.)?#', '', $domain ), '/' );
		$key    = $domain ? $domain : 'org:' . sanitize_title( $o['name'] );

		$id = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE ckey = %s', $t, $key ) );
		if ( $id ) {
			return $id;
		}

		$now = current_time( 'mysql', true );
		$ok  = $wpdb->insert(
			$t,
			array(
				'ckey'       => $key,
				'name'       => substr( (string) $o['name'], 0, 255 ),
				'domain'     => substr( $domain, 0, 190 ),
				'asn'        => substr( (string) $o['asn'], 0, 20 ),
				'city'       => substr( (string) $o['city'], 0, 100 ),
				'region'     => substr( (string) $o['region'], 0, 100 ),
				'country'    => substr( (string) $o['country'], 0, 10 ),
				'first_seen' => $now,
				'last_seen'  => $now,
			)
		);
		if ( ! $ok ) {
			return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE ckey = %s', $t, $key ) );
		}
		$id = (int) $wpdb->insert_id;

		if ( b2bvi_opt( 'enrich', 0 ) && $domain ) {
			wp_schedule_single_event( time() + 5, 'b2bvi_enrich', array( $id ) );
		}
		if ( b2bvi_opt( 'notify_email', '' ) ) {
			wp_schedule_single_event( time() + 20 * MINUTE_IN_SECONDS, 'b2bvi_notify', array( $id ) );
		}

		/**
		 * Fires when a new company is identified.
		 *
		 * @param int   $id Company id.
		 * @param array $o  Lookup result.
		 */
		do_action( 'b2bvi_new_company', $id, $o );

		return $id;
	}
}
