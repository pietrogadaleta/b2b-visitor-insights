<?php
/**
 * Admin screens.
 *
 * @package B2B_Visitor_Insights
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery -- Custom plugin tables; results are not cacheable.

/**
 * Dashboard, company detail, settings, CSV export.
 */
class B2BVI_Admin {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_b2bvi_export', array( __CLASS__, 'export' ) );
		add_action( 'admin_post_b2bvi_delete', array( __CLASS__, 'delete' ) );
		add_action( 'admin_post_b2bvi_test', array( __CLASS__, 'test' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( B2BVI_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Settings link on the Plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=b2bvi-settings' ) ) . '">' . esc_html__( 'Settings', 'b2b-visitor-insights' ) . '</a>' );
		return $links;
	}

	/**
	 * Menu pages.
	 */
	public static function menu() {
		add_menu_page( __( 'B2B Visitors', 'b2b-visitor-insights' ), __( 'B2B Visitors', 'b2b-visitor-insights' ), 'manage_options', 'b2bvi', array( __CLASS__, 'page' ), 'dashicons-building', 26 );
		add_submenu_page( 'b2bvi', __( 'Companies', 'b2b-visitor-insights' ), __( 'Companies', 'b2b-visitor-insights' ), 'manage_options', 'b2bvi', array( __CLASS__, 'page' ) );
		add_submenu_page( 'b2bvi', __( 'Settings', 'b2b-visitor-insights' ), __( 'Settings', 'b2b-visitor-insights' ), 'manage_options', 'b2bvi-settings', array( __CLASS__, 'settings_page' ) );
	}

	/**
	 * Admin CSS on plugin screens only.
	 *
	 * @param string $hook Current screen hook.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'b2bvi' ) ) {
			return;
		}
		wp_enqueue_style( 'b2bvi-admin', B2BVI_URL . 'assets/admin.css', array(), B2BVI_VER );
	}

	/**
	 * Settings registration and privacy policy text.
	 */
	public static function register() {
		register_setting(
			'b2bvi',
			'b2bvi_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);

		if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
			wp_add_privacy_policy_content(
				'B2B Visitor Insights',
				wp_kses_post(
					'<p>' . __( 'With your consent to statistics or marketing cookies, the IP address of your connection is sent to IPinfo Inc. to identify the organization (company network) it belongs to. We use this information for B2B sales analysis: we record the organization name and the pages viewed. We do not identify individual people. IP addresses of private connections (home, mobile, internet providers) are discarded, and IP addresses are never stored in clear text. Data is kept for a limited period and then deleted automatically.', 'b2b-visitor-insights' ) . '</p>'
				)
			);
		}
	}

	/**
	 * Sanitize settings.
	 *
	 * @param mixed $in Raw input.
	 * @return array
	 */
	public static function sanitize( $in ) {
		$in = is_array( $in ) ? wp_unslash( $in ) : array();
		$g  = function ( $k ) use ( $in ) {
			return isset( $in[ $k ] ) ? (string) $in[ $k ] : '';
		};
		// Accept a pasted URL like "https://api.ipinfo.io/lite/8.8.8.8?token=abc123".
		$token = trim( $g( 'ipinfo_token' ) );
		if ( preg_match( '/[?&]token=([A-Za-z0-9]+)/', $token, $m ) ) {
			$token = $m[1];
		}
		return array(
			'enabled'        => empty( $in['enabled'] ) ? 0 : 1,
			'ipinfo_token'   => preg_replace( '/[^A-Za-z0-9]/', '', $token ),
			'ipinfo_plan'    => in_array( $g( 'ipinfo_plan' ), array( 'lite', 'core' ), true ) ? $g( 'ipinfo_plan' ) : 'lite',
			'consent_mode'   => in_array( $g( 'consent_mode' ), array( 'auto', 'cookie', 'none' ), true ) ? $g( 'consent_mode' ) : 'auto',
			'consent_cookie' => preg_replace( '/[^A-Za-z0-9_\-\.]/', '', $g( 'consent_cookie' ) ),
			'ip_header'      => preg_replace( '/[^A-Za-z0-9_\-]/', '', $g( 'ip_header' ) ),
			'exclude_ips'    => sanitize_textarea_field( $g( 'exclude_ips' ) ),
			'isp_extra'      => sanitize_textarea_field( $g( 'isp_extra' ) ),
			'hot_pages'      => sanitize_text_field( $g( 'hot_pages' ) ),
			'enrich'         => empty( $in['enrich'] ) ? 0 : 1,
			'notify_email'   => sanitize_email( $g( 'notify_email' ) ),
			'retention_days' => max( 7, min( 730, absint( $g( 'retention_days' ) ) ) ),
		);
	}

	/**
	 * Companies with activity in the period.
	 *
	 * @param int    $days   Period in days.
	 * @param string $search Search string.
	 * @return array
	 */
	private static function query( $days, $search = '' ) {
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$like  = '%' . $wpdb->esc_like( $search ) . '%';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT c.*, a.pv, a.ss, a.lastv FROM %i c
				INNER JOIN (
					SELECT company_id, COUNT(*) AS pv, COUNT(DISTINCT sid) AS ss, MAX(created) AS lastv
					FROM %i WHERE created >= %s GROUP BY company_id
				) a ON a.company_id = c.id
				WHERE ( %s = \'\' OR c.name LIKE %s OR c.domain LIKE %s )
				ORDER BY a.lastv DESC LIMIT 500',
				B2BVI_DB::t( 'companies' ),
				B2BVI_DB::t( 'visits' ),
				$since,
				$search,
				$like,
				$like
			)
		);

		// Count views of "hot" pages per company.
		$hot    = array_filter( array_map( 'trim', explode( ',', (string) b2bvi_opt( 'hot_pages', '' ) ) ) );
		$hot_by = array();
		if ( $hot && $rows ) {
			$urls = $wpdb->get_results(
				$wpdb->prepare( 'SELECT company_id, url, COUNT(*) AS n FROM %i WHERE created >= %s GROUP BY company_id, url', B2BVI_DB::t( 'visits' ), $since )
			);
			foreach ( $urls as $u ) {
				foreach ( $hot as $h ) {
					if ( false !== stripos( $u->url, $h ) ) {
						$hot_by[ $u->company_id ] = ( isset( $hot_by[ $u->company_id ] ) ? $hot_by[ $u->company_id ] : 0 ) + (int) $u->n;
						break;
					}
				}
			}
		}

		foreach ( $rows as $r ) {
			$r->hot   = isset( $hot_by[ $r->id ] ) ? $hot_by[ $r->id ] : 0;
			$r->score = (int) $r->pv + 3 * (int) $r->ss + 10 * (int) $r->hot;
		}
		return $rows;
	}

	/**
	 * Interest badge.
	 *
	 * @param int $score Score.
	 */
	private static function level( $score ) {
		if ( $score >= 30 ) {
			$class = 'high';
			$label = __( 'High', 'b2b-visitor-insights' );
		} elseif ( $score >= 12 ) {
			$class = 'medium';
			$label = __( 'Medium', 'b2b-visitor-insights' );
		} else {
			$class = 'low';
			$label = __( 'Low', 'b2b-visitor-insights' );
		}
		printf( '<span class="b2bvi-badge b2bvi-%1$s">%2$s</span> <small>%3$d</small>', esc_attr( $class ), esc_html( $label ), (int) $score );
	}

	/**
	 * Local date/time from a GMT MySQL date.
	 *
	 * @param string $gmt GMT date.
	 * @return string
	 */
	private static function dt( $gmt ) {
		return $gmt ? get_date_from_gmt( $gmt, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) : '—';
	}

	/**
	 * Companies list (or detail when ?company= is set).
	 */
	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filters.
		if ( ! empty( $_GET['company'] ) ) {
			self::detail( absint( $_GET['company'] ) );
			return;
		}
		$days   = isset( $_GET['days'] ) ? absint( $_GET['days'] ) : 30;
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$sort   = ( isset( $_GET['sort'] ) && 'score' === $_GET['sort'] ) ? 'score' : 'recent';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		$days = in_array( $days, array( 1, 7, 30, 90, 365 ), true ) ? $days : 30;

		$rows = self::query( $days, $search );
		if ( 'score' === $sort ) {
			usort(
				$rows,
				function ( $a, $b ) {
					return $b->score - $a->score;
				}
			);
		}

		$st   = (array) get_option( 'b2bvi_stats', array() );
		$t    = 0;
		$m    = 0;
		$from = gmdate( 'Y-m-d', time() - ( $days - 1 ) * DAY_IN_SECONDS );
		foreach ( $st as $d => $v ) {
			if ( $d >= $from ) {
				$t += (int) $v['t'];
				$m += (int) $v['m'];
			}
		}
		$rate    = $t ? round( $m / $t * 100, 1 ) : 0;
		$base    = admin_url( 'admin.php?page=b2bvi' );
		$cards   = array(
			__( 'Companies identified', 'b2b-visitor-insights' ) => number_format_i18n( count( $rows ) ),
			__( 'Page views tracked', 'b2b-visitor-insights' ) => number_format_i18n( $t ),
			__( 'Page views from companies', 'b2b-visitor-insights' ) => number_format_i18n( $m ),
			__( 'Match rate', 'b2b-visitor-insights' ) => number_format_i18n( $rate, 1 ) . '%',
		);
		$periods = array(
			1   => __( 'Today', 'b2b-visitor-insights' ),
			7   => __( 'Last 7 days', 'b2b-visitor-insights' ),
			30  => __( 'Last 30 days', 'b2b-visitor-insights' ),
			90  => __( 'Last 90 days', 'b2b-visitor-insights' ),
			365 => __( 'Last 12 months', 'b2b-visitor-insights' ),
		);
		?>
		<div class="wrap b2bvi">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'B2B Visitors', 'b2b-visitor-insights' ); ?></h1>
			<a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=b2bvi_export&days=' . $days ), 'b2bvi_export' ) ); ?>"><?php esc_html_e( 'Export CSV', 'b2b-visitor-insights' ); ?></a>
			<hr class="wp-header-end">

			<?php if ( ! b2bvi_opt( 'enabled', 0 ) || ( ! b2bvi_opt( 'ipinfo_token', '' ) && ! has_filter( 'b2bvi_lookup' ) ) ) : ?>
				<div class="notice notice-warning"><p>
					<?php esc_html_e( 'Tracking is disabled or the IPinfo token is missing.', 'b2b-visitor-insights' ); ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=b2bvi-settings' ) ); ?>"><?php esc_html_e( 'Open settings', 'b2b-visitor-insights' ); ?></a>
				</p></div>
			<?php endif; ?>

			<div class="b2bvi-cards">
				<?php foreach ( $cards as $label => $val ) : ?>
					<div class="b2bvi-card">
						<div class="b2bvi-card-label"><?php echo esc_html( $label ); ?></div>
						<div class="b2bvi-card-value"><?php echo esc_html( $val ); ?></div>
					</div>
				<?php endforeach; ?>
			</div>

			<form method="get" class="b2bvi-filters">
				<input type="hidden" name="page" value="b2bvi">
				<select name="days">
					<?php foreach ( $periods as $k => $l ) : ?>
						<option value="<?php echo (int) $k; ?>" <?php selected( $days, $k ); ?>><?php echo esc_html( $l ); ?></option>
					<?php endforeach; ?>
				</select>
				<select name="sort">
					<option value="recent" <?php selected( $sort, 'recent' ); ?>><?php esc_html_e( 'Most recent', 'b2b-visitor-insights' ); ?></option>
					<option value="score" <?php selected( $sort, 'score' ); ?>><?php esc_html_e( 'Most interested', 'b2b-visitor-insights' ); ?></option>
				</select>
				<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search company or domain', 'b2b-visitor-insights' ); ?>">
				<button class="button"><?php esc_html_e( 'Filter', 'b2b-visitor-insights' ); ?></button>
			</form>

			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Company', 'b2b-visitor-insights' ); ?></th>
					<th><?php esc_html_e( 'Location', 'b2b-visitor-insights' ); ?></th>
					<th><?php esc_html_e( 'Contacts', 'b2b-visitor-insights' ); ?></th>
					<th><?php esc_html_e( 'Sessions', 'b2b-visitor-insights' ); ?></th>
					<th><?php esc_html_e( 'Pages', 'b2b-visitor-insights' ); ?></th>
					<th><?php esc_html_e( 'Interest', 'b2b-visitor-insights' ); ?></th>
					<th><?php esc_html_e( 'Last visit', 'b2b-visitor-insights' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="7"><?php esc_html_e( 'No companies in the selected period yet.', 'b2b-visitor-insights' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $rows as $r ) : ?>
					<tr>
						<td>
							<strong><a href="<?php echo esc_url( add_query_arg( 'company', (int) $r->id, $base ) ); ?>"><?php echo esc_html( $r->name ); ?></a></strong>
							<?php if ( $r->domain ) : ?>
								<br><a href="<?php echo esc_url( 'https://' . $r->domain ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $r->domain ); ?></a>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( trim( $r->city . ' ' . $r->country ) ); ?></td>
						<td>
							<?php if ( $r->email ) : ?>
								<a href="<?php echo esc_url( 'mailto:' . $r->email ); ?>"><?php echo esc_html( $r->email ); ?></a><br>
							<?php endif; ?>
							<?php if ( $r->phone ) : ?>
								<a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $r->phone ) ); ?>"><?php echo esc_html( $r->phone ); ?></a><br>
							<?php endif; ?>
							<?php if ( $r->linkedin ) : ?>
								<a href="<?php echo esc_url( $r->linkedin ); ?>" target="_blank" rel="noopener noreferrer">LinkedIn</a>
							<?php endif; ?>
						</td>
						<td><?php echo (int) $r->ss; ?></td>
						<td><?php echo (int) $r->pv; ?></td>
						<td><?php self::level( $r->score ); ?></td>
						<td><?php echo esc_html( self::dt( $r->lastv ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description">
				<?php
				/* translators: %s: comma-separated list of URL fragments. */
				echo esc_html( sprintf( __( 'Score = page views + 3 × sessions + 10 × "hot" pages (%s).', 'b2b-visitor-insights' ), b2bvi_opt( 'hot_pages', '' ) ) );
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Company detail.
	 *
	 * @param int $id Company id.
	 */
	private static function detail( $id ) {
		global $wpdb;
		$c = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', B2BVI_DB::t( 'companies' ), $id ) );
		echo '<div class="wrap b2bvi">';
		echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=b2bvi' ) ) . '">&larr; ' . esc_html__( 'All companies', 'b2b-visitor-insights' ) . '</a></p>';
		if ( ! $c ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Company not found.', 'b2b-visitor-insights' ) . '</p></div></div>';
			return;
		}
		$visits = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE company_id = %d ORDER BY created DESC LIMIT 1000', B2BVI_DB::t( 'visits' ), $id ) );
		$sess   = array();
		foreach ( $visits as $v ) {
			$sess[ $v->sid ][] = $v;
		}
		$loc = trim( implode( ', ', array_filter( array( $c->city, $c->region, $c->country ) ) ) );
		?>
		<h1><?php echo esc_html( $c->name ); ?></h1>
		<table class="form-table b2bvi-company">
			<tr><th><?php esc_html_e( 'Domain', 'b2b-visitor-insights' ); ?></th><td>
				<?php if ( $c->domain ) : ?>
					<a href="<?php echo esc_url( 'https://' . $c->domain ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $c->domain ); ?></a>
				<?php else : ?>
					—
				<?php endif; ?>
			</td></tr>
			<tr><th><?php esc_html_e( 'Location', 'b2b-visitor-insights' ); ?></th><td><?php echo esc_html( $loc ? $loc : '—' ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Email', 'b2b-visitor-insights' ); ?></th><td>
				<?php if ( $c->email ) : ?>
					<a href="<?php echo esc_url( 'mailto:' . $c->email ); ?>"><?php echo esc_html( $c->email ); ?></a>
				<?php else : ?>
					—
				<?php endif; ?>
			</td></tr>
			<tr><th><?php esc_html_e( 'Phone', 'b2b-visitor-insights' ); ?></th><td><?php echo esc_html( $c->phone ? $c->phone : '—' ); ?></td></tr>
			<tr><th>LinkedIn</th><td>
				<?php if ( $c->linkedin ) : ?>
					<a href="<?php echo esc_url( $c->linkedin ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Company page', 'b2b-visitor-insights' ); ?></a> ·
				<?php endif; ?>
				<a href="<?php echo esc_url( 'https://www.linkedin.com/search/results/people/?keywords=' . rawurlencode( $c->name ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Find people', 'b2b-visitor-insights' ); ?></a>
			</td></tr>
			<tr><th><?php esc_html_e( 'First / last visit', 'b2b-visitor-insights' ); ?></th><td><?php echo esc_html( self::dt( $c->first_seen ) . ' / ' . self::dt( $c->last_seen ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Total', 'b2b-visitor-insights' ); ?></th><td>
				<?php
				/* translators: 1: number of sessions, 2: number of page views. */
				echo esc_html( sprintf( __( '%1$d sessions · %2$d page views', 'b2b-visitor-insights' ), (int) $c->sessions, (int) $c->pageviews ) );
				?>
			</td></tr>
		</table>

		<h2><?php esc_html_e( 'Sessions', 'b2b-visitor-insights' ); ?></h2>
		<?php foreach ( $sess as $pages ) : ?>
			<?php
			$pages = array_reverse( $pages );
			$first = $pages[0];
			$tot   = (int) array_sum( wp_list_pluck( $pages, 'duration' ) );
			$meta  = array(
				/* translators: %d: number of pages. */
				sprintf( _n( '%d page', '%d pages', count( $pages ), 'b2b-visitor-insights' ), count( $pages ) ),
			);
			if ( $tot ) {
				$meta[] = gmdate( 'i:s', min( $tot, 3599 ) ) . ' min';
			}
			if ( $first->referrer ) {
				/* translators: %s: referring website. */
				$meta[] = sprintf( __( 'from %s', 'b2b-visitor-insights' ), wp_parse_url( $first->referrer, PHP_URL_HOST ) );
			}
			if ( $first->utm ) {
				$meta[] = $first->utm;
			}
			?>
			<div class="b2bvi-session">
				<strong><?php echo esc_html( self::dt( $first->created ) ); ?></strong> · <?php echo esc_html( implode( ' · ', $meta ) ); ?>
				<ol>
					<?php foreach ( $pages as $p ) : ?>
						<li>
							<?php echo esc_html( get_date_from_gmt( $p->created, get_option( 'time_format' ) ) ); ?> —
							<a href="<?php echo esc_url( $p->url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $p->title ? $p->title : $p->url ); ?></a>
							<?php if ( $p->duration ) : ?>
								<small>(<?php echo (int) $p->duration; ?>s)</small>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ol>
			</div>
		<?php endforeach; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Delete this company and all its visits?', 'b2b-visitor-insights' ) ); ?>');">
			<input type="hidden" name="action" value="b2bvi_delete">
			<input type="hidden" name="id" value="<?php echo (int) $c->id; ?>">
			<?php wp_nonce_field( 'b2bvi_delete' ); ?>
			<button class="button button-link-delete"><?php esc_html_e( 'Delete this company\'s data', 'b2b-visitor-insights' ); ?></button>
		</form>
		</div>
		<?php
	}

	/**
	 * Settings screen.
	 */
	public static function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o    = wp_parse_args( (array) get_option( 'b2bvi_settings', array() ), b2bvi_defaults() );
		$n    = 'b2bvi_settings';
		$tkey = 'b2bvi_test_' . get_current_user_id();
		$test = get_transient( $tkey );
		if ( $test ) {
			delete_transient( $tkey );
		}
		?>
		<div class="wrap b2bvi">
			<h1><?php esc_html_e( 'B2B Visitors — Settings', 'b2b-visitor-insights' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'b2bvi' ); ?>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Tracking', 'b2b-visitor-insights' ); ?></th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[enabled]" value="1" <?php checked( $o['enabled'], 1 ); ?>> <?php esc_html_e( 'Enable the tracking script on the website', 'b2b-visitor-insights' ); ?></label>
					</td></tr>
					<tr><th><label for="b2bvi-token"><?php esc_html_e( 'IPinfo token', 'b2b-visitor-insights' ); ?></label></th><td>
						<input id="b2bvi-token" type="text" class="regular-text" autocomplete="off" name="<?php echo esc_attr( $n ); ?>[ipinfo_token]" value="<?php echo esc_attr( $o['ipinfo_token'] ); ?>">
						<p class="description">
							<?php
							printf(
								/* translators: %s: link to ipinfo.io. */
								esc_html__( 'Free account on %s → Dashboard → Token. Paste the token only, not a URL.', 'b2b-visitor-insights' ),
								'<a href="https://ipinfo.io/signup" target="_blank" rel="noopener noreferrer">ipinfo.io</a>'
							);
							?>
						</p>
					</td></tr>
					<tr><th><label for="b2bvi-plan"><?php esc_html_e( 'IPinfo plan', 'b2b-visitor-insights' ); ?></label></th><td>
						<select id="b2bvi-plan" name="<?php echo esc_attr( $n ); ?>[ipinfo_plan]">
							<option value="lite" <?php selected( $o['ipinfo_plan'], 'lite' ); ?>><?php esc_html_e( 'Lite (free, ASN data only)', 'b2b-visitor-insights' ); ?></option>
							<option value="core" <?php selected( $o['ipinfo_plan'], 'core' ); ?>><?php esc_html_e( 'Core / Plus / Business (paid)', 'b2b-visitor-insights' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'The free plan only recognizes companies that own their network (mostly large companies). Paid plans with company data also recognize smaller businesses.', 'b2b-visitor-insights' ); ?></p>
					</td></tr>
					<tr><th><label for="b2bvi-consent"><?php esc_html_e( 'Cookie consent', 'b2b-visitor-insights' ); ?></label></th><td>
						<select id="b2bvi-consent" name="<?php echo esc_attr( $n ); ?>[consent_mode]">
							<option value="auto" <?php selected( $o['consent_mode'], 'auto' ); ?>><?php esc_html_e( 'Automatic (Complianz, Cookiebot, iubenda, CookieYes, CookieLawInfo)', 'b2b-visitor-insights' ); ?></option>
							<option value="cookie" <?php selected( $o['consent_mode'], 'cookie' ); ?>><?php esc_html_e( 'Custom cookie', 'b2b-visitor-insights' ); ?></option>
							<option value="none" <?php selected( $o['consent_mode'], 'none' ); ?>><?php esc_html_e( 'No consent check (not recommended in the EU)', 'b2b-visitor-insights' ); ?></option>
						</select>
						<p><input type="text" name="<?php echo esc_attr( $n ); ?>[consent_cookie]" value="<?php echo esc_attr( $o['consent_cookie'] ); ?>" placeholder="<?php esc_attr_e( 'consent cookie name', 'b2b-visitor-insights' ); ?>"></p>
						<p class="description"><?php esc_html_e( 'The script only runs after consent to the Statistics or Marketing category.', 'b2b-visitor-insights' ); ?></p>
					</td></tr>
					<tr><th><label for="b2bvi-header"><?php esc_html_e( 'Real IP header', 'b2b-visitor-insights' ); ?></label></th><td>
						<input id="b2bvi-header" type="text" name="<?php echo esc_attr( $n ); ?>[ip_header]" value="<?php echo esc_attr( $o['ip_header'] ); ?>" placeholder="CF-Connecting-IP">
						<p class="description"><?php esc_html_e( 'Only if the site is behind Cloudflare or a reverse proxy. Otherwise leave empty.', 'b2b-visitor-insights' ); ?></p>
					</td></tr>
					<tr><th><label for="b2bvi-exclude"><?php esc_html_e( 'Excluded IPs', 'b2b-visitor-insights' ); ?></label></th><td>
						<textarea id="b2bvi-exclude" rows="3" class="large-text" name="<?php echo esc_attr( $n ); ?>[exclude_ips]"><?php echo esc_textarea( $o['exclude_ips'] ); ?></textarea>
						<p class="description">
							<?php esc_html_e( 'One per line; end with * to match a prefix.', 'b2b-visitor-insights' ); ?>
							<?php
							$b2bvi_ip = B2BVI_Tracker::ip();
							if ( $b2bvi_ip ) {
								/* translators: %s: IP address. */
								printf( esc_html__( 'Your current IP: %s', 'b2b-visitor-insights' ), '<code>' . esc_html( $b2bvi_ip ) . '</code>' );
							}
							?>
						</p>
					</td></tr>
					<tr><th><label for="b2bvi-isp"><?php esc_html_e( 'Providers to ignore', 'b2b-visitor-insights' ); ?></label></th><td>
						<textarea id="b2bvi-isp" rows="2" class="large-text" name="<?php echo esc_attr( $n ); ?>[isp_extra]"><?php echo esc_textarea( $o['isp_extra'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Extra ISP or hosting names to discard (one per line). Major providers are already included.', 'b2b-visitor-insights' ); ?></p>
					</td></tr>
					<tr><th><label for="b2bvi-hot"><?php esc_html_e( 'Hot pages', 'b2b-visitor-insights' ); ?></label></th><td>
						<input id="b2bvi-hot" type="text" class="large-text" name="<?php echo esc_attr( $n ); ?>[hot_pages]" value="<?php echo esc_attr( $o['hot_pages'] ); ?>">
						<p class="description"><?php esc_html_e( 'Comma-separated URL fragments of high-intent pages (contact, pricing, services). They raise the interest score.', 'b2b-visitor-insights' ); ?></p>
					</td></tr>
					<tr><th><?php esc_html_e( 'Contact enrichment', 'b2b-visitor-insights' ); ?></th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[enrich]" value="1" <?php checked( $o['enrich'], 1 ); ?>> <?php esc_html_e( 'Read the public email, phone and LinkedIn page from the company\'s own website', 'b2b-visitor-insights' ); ?></label>
						<p class="description"><?php esc_html_e( 'Off by default. When enabled, your server requests a few pages (home, contact) of each newly identified company\'s website.', 'b2b-visitor-insights' ); ?></p>
					</td></tr>
					<tr><th><label for="b2bvi-email"><?php esc_html_e( 'Notification email', 'b2b-visitor-insights' ); ?></label></th><td>
						<input id="b2bvi-email" type="email" class="regular-text" name="<?php echo esc_attr( $n ); ?>[notify_email]" value="<?php echo esc_attr( $o['notify_email'] ); ?>">
						<p class="description"><?php esc_html_e( 'An alert for every new company (leave empty to disable).', 'b2b-visitor-insights' ); ?></p>
					</td></tr>
					<tr><th><label for="b2bvi-ret"><?php esc_html_e( 'Data retention', 'b2b-visitor-insights' ); ?></label></th><td>
						<input id="b2bvi-ret" type="number" min="7" max="730" name="<?php echo esc_attr( $n ); ?>[retention_days]" value="<?php echo (int) $o['retention_days']; ?>"> <?php esc_html_e( 'days', 'b2b-visitor-insights' ); ?>
					</td></tr>
				</table>
				<?php submit_button(); ?>
			</form>

			<hr>
			<h2><?php esc_html_e( 'Test lookup', 'b2b-visitor-insights' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="b2bvi_test">
				<?php wp_nonce_field( 'b2bvi_test' ); ?>
				<input type="text" name="ip" placeholder="8.8.8.8" value="<?php echo esc_attr( $test ? $test['ip'] : '' ); ?>">
				<button class="button"><?php esc_html_e( 'Check', 'b2b-visitor-insights' ); ?></button>
			</form>
			<?php if ( $test ) : ?>
				<div class="b2bvi-test">
					<?php if ( is_array( $test['r'] ) ) : ?>
						<strong><?php echo esc_html( $test['r']['name'] ); ?></strong> <?php echo esc_html( $test['r']['domain'] ); ?><br>
						<?php echo esc_html( trim( $test['r']['asn'] . ' · ' . $test['r']['city'] . ' ' . $test['r']['country'], ' ·' ) ); ?><br>
						<?php if ( $test['r']['is_isp'] ) : ?>
							<strong><?php esc_html_e( 'Result: ISP / hosting — discarded', 'b2b-visitor-insights' ); ?></strong>
						<?php else : ?>
							<strong><?php esc_html_e( 'Result: company — tracked', 'b2b-visitor-insights' ); ?></strong>
						<?php endif; ?>
					<?php elseif ( 'invalid' === $test['r'] ) : ?>
						<?php esc_html_e( 'Invalid IP address.', 'b2b-visitor-insights' ); ?>
					<?php else : ?>
						<?php esc_html_e( 'API error: token missing or invalid, or limit reached.', 'b2b-visitor-insights' ); ?>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Lookup test handler.
	 */
	public static function test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'b2b-visitor-insights' ) );
		}
		check_admin_referer( 'b2bvi_test' );
		$ip = isset( $_POST['ip'] ) ? sanitize_text_field( wp_unslash( $_POST['ip'] ) ) : '';
		$r  = filter_var( $ip, FILTER_VALIDATE_IP ) ? B2BVI_Lookup::lookup( $ip ) : 'invalid';
		set_transient(
			'b2bvi_test_' . get_current_user_id(),
			array(
				'ip' => $ip,
				'r'  => $r,
			),
			300
		);
		wp_safe_redirect( admin_url( 'admin.php?page=b2bvi-settings' ) );
		exit;
	}

	/**
	 * CSV export.
	 */
	public static function export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'b2b-visitor-insights' ) );
		}
		check_admin_referer( 'b2bvi_export' );
		$days = isset( $_GET['days'] ) ? max( 1, min( 365, absint( $_GET['days'] ) ) ) : 30;
		$rows = self::query( $days );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=b2b-visitors-' . gmdate( 'Y-m-d' ) . '.csv' );
		// phpcs:disable WordPress.WP.AlternativeFunctions -- Streaming CSV to the browser.
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv(
			$out,
			array(
				__( 'Company', 'b2b-visitor-insights' ),
				__( 'Domain', 'b2b-visitor-insights' ),
				__( 'City', 'b2b-visitor-insights' ),
				__( 'Country', 'b2b-visitor-insights' ),
				__( 'Email', 'b2b-visitor-insights' ),
				__( 'Phone', 'b2b-visitor-insights' ),
				'LinkedIn',
				__( 'Sessions', 'b2b-visitor-insights' ),
				__( 'Page views', 'b2b-visitor-insights' ),
				__( 'Hot pages', 'b2b-visitor-insights' ),
				__( 'Score', 'b2b-visitor-insights' ),
				__( 'Last visit', 'b2b-visitor-insights' ),
				__( 'URLs visited', 'b2b-visitor-insights' ),
			),
			';',
			'"',
			'\\'
		);
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		foreach ( $rows as $r ) {
			$urls = $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT url FROM %i WHERE company_id = %d AND created >= %s LIMIT 50', B2BVI_DB::t( 'visits' ), $r->id, $since ) );
			fputcsv(
				$out,
				array( $r->name, $r->domain, $r->city, $r->country, $r->email, $r->phone, $r->linkedin, $r->ss, $r->pv, $r->hot, $r->score, get_date_from_gmt( $r->lastv, 'Y-m-d H:i' ), implode( ' | ', $urls ) ),
				';',
				'"',
				'\\'
			);
		}
		fclose( $out );
		// phpcs:enable WordPress.WP.AlternativeFunctions
		exit;
	}

	/**
	 * Delete one company's data.
	 */
	public static function delete() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'b2b-visitor-insights' ) );
		}
		check_admin_referer( 'b2bvi_delete' );
		global $wpdb;
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( $id ) {
			$wpdb->delete( B2BVI_DB::t( 'visits' ), array( 'company_id' => $id ) );
			$wpdb->delete( B2BVI_DB::t( 'ip_cache' ), array( 'company_id' => $id ) );
			$wpdb->delete( B2BVI_DB::t( 'companies' ), array( 'id' => $id ) );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=b2bvi' ) );
		exit;
	}
}
